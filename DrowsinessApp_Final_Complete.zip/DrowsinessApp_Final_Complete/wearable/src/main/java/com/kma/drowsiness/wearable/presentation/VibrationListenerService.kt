package com.kma.drowsiness.wearable.presentation

// Wearable Module: VibrationListenerService.kt (이 내용을 전부 붙여넣으세요)

import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

// 이 클래스는 WearableListenerService를 상속받아 폰의 메시지를 기다립니다.
class VibrationListenerService : WearableListenerService() {

    // 폰에서 보낸 메시지 경로와 동일해야 함
    private val PATH_VIBRATE = "/vibrate_command"

    override fun onMessageReceived(messageEvent: MessageEvent) {
        // 수신된 메시지의 경로가 진동 명령 경로와 일치하는지 확인
        if (messageEvent.path == PATH_VIBRATE) {
            Log.d("Watch", "진동 명령 수신! 진동 실행.")
            startStrongVibration()
        }
    }

    private fun startStrongVibration() {
        val vibrator = getSystemService(Vibrator::class.java) as Vibrator

        // 강력한 진동 패턴 정의: 0ms 대기, 1000ms 진동
        val pattern = longArrayOf(0, 1000)

        // ... (중략: 진동 실행 로직) ...
        if (vibrator.hasVibrator()) {
            val effect = VibrationEffect.createWaveform(pattern, -1) // -1은 반복 없음 (1회만 진동)
            vibrator.vibrate(effect)
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(pattern, -1)
        }
        Log.i("Watch", "강력한 진동 실행됨.")
    }
}